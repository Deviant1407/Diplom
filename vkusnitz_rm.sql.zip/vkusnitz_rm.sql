-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Сен 19 2024 г., 21:04
-- Версия сервера: 5.7.21-20-beget-5.7.21-20-1-log
-- Версия PHP: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `vkusnitz_rm`
--

-- --------------------------------------------------------

--
-- Структура таблицы `Films`
--
-- Создание: Сен 19 2024 г., 17:19
--

DROP TABLE IF EXISTS `Films`;
CREATE TABLE `Films` (
  `ID` int(11) NOT NULL,
  `Name` varchar(255) DEFAULT NULL,
  `Description` text,
  `Evaluation` float DEFAULT NULL,
  `Release_Year` int(11) DEFAULT NULL,
  `Country` varchar(255) DEFAULT NULL,
  `Genre` text,
  `URL_Image` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `Role`
--
-- Создание: Сен 19 2024 г., 17:24
-- Последнее обновление: Сен 19 2024 г., 17:29
--

DROP TABLE IF EXISTS `Role`;
CREATE TABLE `Role` (
  `ID` int(11) NOT NULL,
  `Name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `Role`
--

INSERT INTO `Role` (`ID`, `Name`) VALUES
(1, 'Пользователь'),
(2, 'Модератор'),
(3, 'Администратор');

-- --------------------------------------------------------

--
-- Структура таблицы `User`
--
-- Создание: Сен 19 2024 г., 17:25
-- Последнее обновление: Сен 19 2024 г., 17:32
--

DROP TABLE IF EXISTS `User`;
CREATE TABLE `User` (
  `ID` int(11) NOT NULL,
  `Username` varchar(255) DEFAULT NULL,
  `FIO` varchar(255) DEFAULT NULL,
  `Password` varchar(255) DEFAULT NULL,
  `Telegram_ID` varchar(255) DEFAULT NULL,
  `ID_role` int(11) DEFAULT NULL,
  `Phone` varchar(255) DEFAULT NULL,
  `Like_film` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `User`
--

INSERT INTO `User` (`ID`, `Username`, `FIO`, `Password`, `Telegram_ID`, `ID_role`, `Phone`, `Like_film`) VALUES
(1, 'Konaca', 'Ямковой Владислав Егорович', 'de91dbed4a18dd02731c2c678966ce56', NULL, 3, NULL, NULL);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `Films`
--
ALTER TABLE `Films`
  ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `Role`
--
ALTER TABLE `Role`
  ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `User`
--
ALTER TABLE `User`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `Username` (`Username`),
  ADD UNIQUE KEY `Telegram_ID` (`Telegram_ID`),
  ADD KEY `ID_role` (`ID_role`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `Films`
--
ALTER TABLE `Films`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `Role`
--
ALTER TABLE `Role`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `User`
--
ALTER TABLE `User`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `User`
--
ALTER TABLE `User`
  ADD CONSTRAINT `User_ibfk_1` FOREIGN KEY (`ID_role`) REFERENCES `Role` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
